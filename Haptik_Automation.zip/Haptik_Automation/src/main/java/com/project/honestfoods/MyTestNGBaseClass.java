package com.project.honestfoods;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class MyTestNGBaseClass {
	
	public WebDriver oDriver;
	public static ExtentReports oExtentReport;
	public static ExtentTest oExtentTest;
	
	

	@BeforeSuite
	public void BeforeSuite() throws Throwable{
		oExtentReport = new ExtentReports("Reports/TestSuiteReport.html", true);
	}
	
	//********************************************************
	//preconditions
	//********************************************************
	@Parameters({ "browser", "url" })

	@BeforeClass
	public void automationSetup(String sBrowserName,String sUrl) throws Exception
	{
		
		oDriver = CommonLib.getDriver(sBrowserName);
		oDriver.get(sUrl);
	    oDriver.manage().window().maximize();

	}

	//********************************************************
	//End of execution
	//********************************************************
	@AfterClass
	public void automationTeardown() throws Exception
	{
//		oDriver.quit();
	}
	
	@AfterSuite
	public void afterSuite()  throws Throwable{
		oExtentReport.endTest(oExtentTest);
		oExtentReport.flush();
	}

}
