package com.project.honestfoods;

public class AutomationConstants 

{
	
	public static String sChromeDriverPath  	= "/Exes/chromedriver";
	
	public static long lngPageLoadTimeout 		= 60L;
	public static long lngImplicitWaitTimeout	= 30L;

	
}
