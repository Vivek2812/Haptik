package tests;

import java.util.HashMap;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import com.project.honestfoods.MyTestNGBaseClass;
import pages.DashBoard;

public class TestCaseOne extends MyTestNGBaseClass {
	static HashMap dataMap = null;

	@Test
	public void validation() throws Throwable {

		oExtentTest = oExtentReport.startTest("Testing Haptik ChatBot");
		DashBoard obj = new DashBoard(oDriver, oExtentReport, oExtentTest, dataMap);
		Thread.sleep(2000);
		
		AssertJUnit.assertTrue(obj.clickChatBox());
		
		AssertJUnit.assertTrue(obj.hoverOptions());
		
		AssertJUnit.assertTrue(obj.clickHaptikProducts());
		
		AssertJUnit.assertTrue(obj.clickArrow());
		Thread.sleep(2000);
		
		AssertJUnit.assertTrue(obj.clickKnowMore());
		Thread.sleep(3000);
		
		AssertJUnit.assertTrue(obj.clickSeeExample());
		Thread.sleep(3000);
		
		AssertJUnit.assertTrue(obj.clickNotMyProblem());
		Thread.sleep(7000);

		AssertJUnit.assertTrue(obj.clickDownArrow());
		Thread.sleep(3000);
		
		AssertJUnit.assertTrue(obj.clickHaptikProducts());
		Thread.sleep(3000);
		
		AssertJUnit.assertTrue(obj.getChatBotDetails());
		Thread.sleep(3000);

		AssertJUnit.assertTrue(obj.closeChatBot());

	}

}
