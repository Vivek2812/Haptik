package pages;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class DashBoard {
	WebDriver oDriver;
	ExtentReports oExtentReports;
	ExtentTest oExtentTest;
	HashMap dictionary;

	public DashBoard(WebDriver oDriver, ExtentReports oExtentReports, ExtentTest oExtentTest, HashMap dictionary) {
		this.oExtentReports = oExtentReports;
		this.oDriver = oDriver;
		this.dictionary = dictionary;
		this.oExtentTest = oExtentTest;
	}
	
	//------------All the Xpaths------------//
	By chatBot = By.xpath("//span[contains(text(),'Let')]");
	By iFrame = By.id("haptik-js-sdk");
	By GetAChatBot = By.xpath("//*[contains(text(),'Get a Chatbot')]");
	By LearnAboutChatBots = By.xpath("//*[contains(text(),'Learn About Chatbots')]");
	By HapticProducts = By.xpath("//*[contains(text(),'Haptik Products')]");
	By Arrow= By.xpath("(//*[@id='a'])");
	By Arrow1= By.xpath("(//*[@id='a'])[2]");
	By KnowMore = By.xpath("(//div[contains(text(),'Know More')])[4]");
	By TextArea= By.xpath("//*[@id=\"composer-text-area\"]");
	By SeeExamlpe =  By.xpath("(//div[@class='qr-item'])[2]");
	By SeeExamlpe1 =  By.xpath("//*[contains(text(),'See an example')]");
	By NotProblem =  By.xpath("//*[contains(text(),'Not my problem')]");
	By DownArrow = By.xpath("//*[@id=\"Rectangle\"]");
	By HaptikBot = By.xpath("//div[@class='header-top-left-text-title']");
	By ChatClose =By.xpath("//span[contains(text(),'Chat!')]");

	public boolean clickChatBox() {
		
		WebDriverWait wait = new WebDriverWait(oDriver, 10);
		// Find frame or iframe and switch
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(iFrame));
		WebElement cB = oDriver.findElement(chatBot);
		cB.click();
		oExtentTest.log(LogStatus.PASS, "ChatBox Clicked");
		
		return true;
	}

	public boolean hoverOptions() throws InterruptedException {
		
		WebElement gChatBot = oDriver.findElement(GetAChatBot);
		WebElement lChatBot = oDriver.findElement(LearnAboutChatBots);
		Thread.sleep(1000);
		hoverMethod(gChatBot);
		Thread.sleep(1000);
		hoverMethod(lChatBot);
		Thread.sleep(1000);
		oExtentTest.log(LogStatus.PASS, "Hovered on Elements");
		
		return true;
	}

	public boolean clickHaptikProducts() {
		
		WebElement hProducts = oDriver.findElement(HapticProducts);
		hProducts.click();
		oExtentTest.log(LogStatus.PASS, "Clicking Haptik Products");
		
		return true;
	}

	public boolean clickArrow() throws InterruptedException {
		
		WebElement arrow= oDriver.findElement(Arrow);
		Actions action = new Actions(oDriver);
		action.moveToElement(arrow).click().perform();
		WebElement arrow1= oDriver.findElement(Arrow1);	
		Thread.sleep(1000);
		action.moveToElement(arrow).click().perform();
		Thread.sleep(1000);
		action.moveToElement(arrow1).click().perform();
		Thread.sleep(1000);
		oExtentTest.log(LogStatus.PASS, "Clicking on Side Arrow");
		
		return true;
	}

	public boolean clickKnowMore() {

		WebElement knowmore= oDriver.findElement(KnowMore);
		knowmore.click();
		oExtentTest.log(LogStatus.PASS, "Clicking on KNow More");
		
		return true;
	}

	public boolean clickSeeExample() {

		WebElement seeExample= oDriver.findElement(SeeExamlpe1);
		hoverMethod(seeExample);
		seeExample.click();
		oExtentTest.log(LogStatus.PASS, "Clicking on See Example");

		return true;
	}

	public boolean clickNotMyProblem() {

		WebElement nmp= oDriver.findElement(NotProblem);
		hoverMethod(nmp);
		nmp.click();
		oExtentTest.log(LogStatus.PASS, "Clicking on Not My Problem");

		return true;
	}

	public boolean clickDownArrow() {

		WebElement downArrow= oDriver.findElement(DownArrow);
		downArrow.click();
		oExtentTest.log(LogStatus.PASS, "Clicking on Down Arrow");

		return true;
	}
	
	public boolean getChatBotDetails() {
		
		WebElement text= oDriver.findElement(HaptikBot);
		String HaptikOnline=text.getText();
		Assert.assertEquals(HaptikOnline,"Haptik is online");
		oExtentTest.log(LogStatus.PASS, "Verifyog ChatBox is Oline");

		return true;
	}
	
public boolean closeChatBot() {
		
		WebElement close= oDriver.findElement(ChatClose);
		close.click();
		oExtentTest.log(LogStatus.PASS, "Closing Chatbot");

		return true;
	}
	

	//--------------Diffrent methods to hover and click-----------//

	public void hoverMethod(WebElement elementToHover) {
		
		Actions action = new Actions(oDriver);
		action.moveToElement(elementToHover).build().perform();
		
	}

	
	public void hoverAndClickMethod(WebElement elementToHover) {
		
		Actions action = new Actions(oDriver);
		action.moveToElement(elementToHover).doubleClick().build().perform();
		
	}
}
